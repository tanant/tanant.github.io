message = """\
        Data ROI: {data_roi}
        Disp ROI: {disp_roi}
      all pixels: {px}x{py}
  display window: {dx}x{dy}"""

import OpenImageIO as oiio

target_image = oiio.ImageInput.open('./render_corrected_nuke.exr')
image_spec = target_image.spec()  # the Spec is the file specification.

# NOTE: "Full" might sound confusing, but recall that often you have full frame
# but you only render a tiny CG element hence the ROI is smaller. 
# For Overscan, this is confusing, but you know.. we had to pick _a_ term.
print ("Target image spec says..")
print (message.format(
            px=image_spec.width,
            py=image_spec.height,
            dx=image_spec.full_width,
            dy=image_spec.full_height,
            data_roi=oiio.get_roi(image_spec),
            disp_roi=oiio.get_roi_full(image_spec))
        )
print ("-"*10)

# let's inspect what we have for our 'oversize' render
base_image = oiio.ImageInput.open('./render_full.exr')
image_spec = base_image.spec()  # the Spec is the file specification.
print ("Source image spec says..")
print (message.format(
            px=image_spec.width,
            py=image_spec.height,
            dx=image_spec.full_width,
            dy=image_spec.full_height,
            data_roi=oiio.get_roi(image_spec),
            disp_roi=oiio.get_roi_full(image_spec))
        )
print ("-"*10)