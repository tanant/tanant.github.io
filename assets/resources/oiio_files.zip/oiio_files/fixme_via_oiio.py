import OpenImageIO as oiio

base_image = oiio.ImageInput.open('./render_full.exr')  # open our source
new_image_spec = base_image.spec()  # lets take the old spec as our starting point

# you'll need to calculate this, obviously
oiio.set_roi(new_image_spec, oiio.ROI(-320, 1600, -180, 900))  
oiio.set_roi_full(new_image_spec, oiio.ROI(0, 1280, 0, 720))

output = oiio.ImageOutput.create('./render_corrected_oiio.exr')
# In 2.0.5 which i'm using, you do not pass the third arg.
# In 1.7 which we have at work, you do.
# output.open('./render_corrected_oiio.exr', new_image_spec, oiio.Create)
output.open('./render_corrected_oiio.exr', new_image_spec)

# Note the copy_image call - we do _not_ want to uncompress/recompress
# pixels needlessly. Let's leave the CPU alone to finish calculating bokeh.
output.copy_image(base_image)
output.close()
# tadah!